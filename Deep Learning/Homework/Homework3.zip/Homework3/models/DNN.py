from .BaseNN import *


class DNN(BaseNN):

    def network(self, X):
        pass

    def metrics(self, Y, Y_pred):
        pass
